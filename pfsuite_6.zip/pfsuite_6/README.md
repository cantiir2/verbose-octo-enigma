# How to RUn the BOT PFSuite


1. Install Nodejs  version 18 
2. Install yarn using the command
        npm i -g yarn
3. Install all packages
        yarn install
        yarn add ts-node typescript

4. Edit the .env file and add privatekeys mainWallet - for Deployment,  senderWallet - For Sending Funds to buyer wallets.

5. Start the bot --  yarn start




